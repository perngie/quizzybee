//
//  quizzybeeTests.swift
//  quizzybeeTests
//
//  Created by 李雨欣 on 2024/11/8.
//

import Testing
@testable import quizzybee

struct quizzybeeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
